﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMICalculator22IS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            double rost = Convert.ToDouble(textBox1.Text) /100;
            double ves = Convert.ToDouble(textBox2.Text);
            int BMI = Convert.ToInt32(ves / (rost * rost));
            label5.Text = BMI.ToString();
            // trackBar1.Value = Convert.ToInt32(BMI);
            if (BMI < 18.5)
                label6.Text = "Недостаточный вес";
            if (BMI > 18.5 && BMI < 24.9)
                label6.Text = "Здоровый вес";
            if (BMI > 25 && BMI < 29.9)
                label6.Text = "Избыточный вес";
            if (BMI > 30)
                label6.Text = "Ожирение";
            trackBar1.Value = Convert.ToInt32(BMI);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = button3.BackgroundImage;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = button4.BackgroundImage;
        }
    }
}
